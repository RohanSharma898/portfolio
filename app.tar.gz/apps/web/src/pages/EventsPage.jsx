
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import EventCard from '@/components/EventCard';
import { Button } from '@/components/ui/button';

const EventsPage = () => {
  const [activeFilter, setActiveFilter] = useState('all');

  const events = [
    {
      id: 1,
      title: 'Neon Nights: Summer Edition',
      date: 'July 15, 2026',
      location: 'Casa Fiesta Main Floor',
      capacity: 847,
      vibe: 'High Energy',
      type: 'party',
      image: 'https://images.unsplash.com/photo-1571433172993-6738d818cfd9'
    },
    {
      id: 2,
      title: 'Underground Sessions Vol. 12',
      date: 'June 28, 2026',
      location: 'Casa Fiesta Basement',
      capacity: 423,
      vibe: 'Deep House',
      type: 'music',
      image: 'https://images.unsplash.com/photo-1680445530925-af01b317e0a6'
    },
    {
      id: 3,
      title: 'VIP Exclusive: Midnight Gala',
      date: 'August 3, 2026',
      location: 'Casa Fiesta Rooftop',
      capacity: 287,
      vibe: 'Luxury',
      type: 'vip',
      image: 'https://images.unsplash.com/photo-1557156105-c792d5220944'
    },
    {
      id: 4,
      title: 'Electric Dreams Festival',
      date: 'September 12, 2026',
      location: 'Casa Fiesta All Floors',
      capacity: 1247,
      vibe: 'Festival',
      type: 'party',
      image: 'https://images.unsplash.com/photo-1571433172993-6738d818cfd9'
    },
    {
      id: 5,
      title: 'Techno Tuesdays',
      date: 'Every Tuesday',
      location: 'Casa Fiesta Main Floor',
      capacity: 634,
      vibe: 'Techno',
      type: 'music',
      image: 'https://images.unsplash.com/photo-1680445530925-af01b317e0a6'
    },
    {
      id: 6,
      title: 'Champagne & Beats',
      date: 'July 22, 2026',
      location: 'Casa Fiesta VIP Lounge',
      capacity: 156,
      vibe: 'Sophisticated',
      type: 'vip',
      image: 'https://images.unsplash.com/photo-1557156105-c792d5220944'
    }
  ];

  const filters = [
    { id: 'all', label: 'All events' },
    { id: 'party', label: 'Party' },
    { id: 'music', label: 'Music' },
    { id: 'vip', label: 'VIP' }
  ];

  const filteredEvents = activeFilter === 'all'
    ? events
    : events.filter(event => event.type === activeFilter);

  return (
    <>
      <Helmet>
        <title>Events - Casa Fiesta</title>
        <meta name="description" content="Browse upcoming and past events at Casa Fiesta. Premium parties, exclusive VIP experiences, and unforgettable nights." />
      </Helmet>

      <div className="min-h-screen bg-background text-white">
        <Header />

        <main className="pt-32 pb-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight text-white" style={{ letterSpacing: '-0.02em' }}>
                Upcoming events
              </h1>
              <p className="text-xl text-white/70 mb-12 max-w-3xl leading-relaxed">
                Experience the energy. Join the most exclusive parties in the city.
              </p>

              {/* Filters */}
              <div className="flex flex-wrap gap-3 mb-12">
                {filters.map((filter) => (
                  <Button
                    key={filter.id}
                    onClick={() => setActiveFilter(filter.id)}
                    variant={activeFilter === filter.id ? 'default' : 'outline'}
                    className={`transition-all duration-200 ${
                      activeFilter === filter.id
                        ? 'bg-primary text-white neon-glow'
                        : 'border-primary/20 text-white hover:border-primary/60 hover:text-white'
                    }`}
                  >
                    {filter.label}
                  </Button>
                ))}
              </div>

              {/* Events Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredEvents.map((event, index) => (
                  <EventCard key={event.id} event={event} index={index} />
                ))}
              </div>

              {filteredEvents.length === 0 && (
                <div className="text-center py-20">
                  <p className="text-lg text-white/60">No events found for this filter.</p>
                </div>
              )}
            </motion.div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default EventsPage;
