
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, Zap, Users, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const HomePage = () => {
  const featuredEvent = {
    title: 'Neon Nights: Summer Edition',
    date: 'July 15, 2026',
    location: 'Casa Fiesta Main Floor',
    image: 'https://images.unsplash.com/photo-1557156105-c792d5220944'
  };

  const stats = [
    { icon: Users, value: '12,847', label: 'Members' },
    { icon: Calendar, value: '247', label: 'Events hosted' },
    { icon: Zap, value: '98.3%', label: 'Satisfaction rate' }
  ];

  return (
    <>
      <Helmet>
        <title>Casa Fiesta - The most exclusive underground party experience</title>
        <meta name="description" content="Join the most exclusive underground party scene. Premium events, VIP experiences, and unforgettable nights at Casa Fiesta." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header />

        {/* Hero Section */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
          <div className="absolute inset-0">
            <img
              src={featuredEvent.image}
              alt="Casa Fiesta atmosphere"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background/95 via-background/80 to-background/95" />
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight text-white" style={{ letterSpacing: '-0.02em' }}>
                Where luxury meets
                <span className="block bg-gradient-to-r from-[hsl(var(--primary-text))] via-[hsl(var(--accent-text))] to-[hsl(var(--secondary-text))] bg-clip-text text-transparent neon-text-glow">
                  underground energy
                </span>
              </h1>
              <p className="text-xl md:text-2xl text-white mb-8 max-w-3xl mx-auto leading-relaxed">
                Experience the most exclusive nightlife destination. Premium events, curated vibes, unforgettable moments.
              </p>
              <Link to="/events">
                <Button className="bg-primary text-white hover:bg-primary/80 neon-glow text-lg px-8 py-6 transition-all duration-200 active:scale-[0.98]">
                  Explore events
                  <ArrowRight className="ml-2 h-5 w-5 text-white" />
                </Button>
              </Link>
            </motion.div>

            {/* Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-20"
            >
              {stats.map((stat, index) => (
                <Card key={index} className="bg-card/50 backdrop-blur-sm border-primary/20">
                  <CardContent className="p-6 text-center">
                    <stat.icon className="h-8 w-8 text-[hsl(var(--primary-text))] mx-auto mb-3" />
                    <div className="text-3xl font-bold text-[hsl(var(--primary-text))] neon-text mb-1">{stat.value}</div>
                    <div className="text-sm text-white/90 font-medium">{stat.label}</div>
                  </CardContent>
                </Card>
              ))}
            </motion.div>
          </div>

          {/* Animated background elements */}
          <div className="absolute inset-0 pointer-events-none">
            <motion.div
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.3, 0.5, 0.3]
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl"
            />
            <motion.div
              animate={{
                scale: [1, 1.3, 1],
                opacity: [0.2, 0.4, 0.2]
              }}
              transition={{
                duration: 5,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 1
              }}
              className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/20 rounded-full blur-3xl"
            />
          </div>
        </section>

        {/* Featured Event */}
        <section className="py-24 bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-white">
                Next up at Casa Fiesta
              </h2>
              <Card className="overflow-hidden border-primary/20 hover:border-primary/60 transition-all duration-300 hover:shadow-neon bg-card">
                <div className="grid md:grid-cols-2 gap-0">
                  <div className="relative h-80 md:h-auto">
                    <img
                      src={featuredEvent.image}
                      alt={featuredEvent.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-8 flex flex-col justify-center">
                    <h3 className="text-2xl md:text-3xl font-bold mb-4 text-[hsl(var(--secondary-text))]">{featuredEvent.title}</h3>
                    <div className="space-y-3 text-white mb-6">
                      <div className="flex items-center space-x-2 font-medium">
                        <Calendar className="h-5 w-5 text-[hsl(var(--primary-text))]" />
                        <span>{featuredEvent.date}</span>
                      </div>
                      <div className="flex items-center space-x-2 font-medium">
                        <Zap className="h-5 w-5 text-[hsl(var(--primary-text))]" />
                        <span>{featuredEvent.location}</span>
                      </div>
                    </div>
                    <Link to="/tickets">
                      <Button className="bg-primary text-white hover:bg-primary/90 neon-glow transition-all duration-200 active:scale-[0.98]">
                        Get tickets
                        <ArrowRight className="ml-2 h-5 w-5" />
                      </Button>
                    </Link>
                  </CardContent>
                </div>
              </Card>
            </motion.div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default HomePage;
