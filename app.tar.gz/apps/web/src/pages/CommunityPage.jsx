
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import TestimonialCard from '@/components/TestimonialCard';
import ViralMomentCard from '@/components/ViralMomentCard';

const CommunityPage = () => {
  const testimonials = [
    {
      name: 'Maya Chen',
      photo: 'https://i.pravatar.cc/150?img=1',
      rating: 5,
      quote: 'Casa Fiesta changed my entire perspective on nightlife. The energy, the people, the production quality - everything is next level. I\'ve been to every major club in Miami, and nothing compares.'
    },
    {
      name: 'Raj Patel',
      photo: 'https://i.pravatar.cc/150?img=12',
      rating: 5,
      quote: 'The VIP experience is worth every penny. From the moment you walk in, you feel like royalty. The staff remembers your name, your drink preferences - it\'s incredibly personal.'
    },
    {
      name: 'Lucia Torres',
      photo: 'https://i.pravatar.cc/150?img=5',
      rating: 5,
      quote: 'I\'ve made lifelong friends at Casa Fiesta. It\'s not just a club, it\'s a community of people who appreciate quality experiences and good vibes. The Underground Sessions are my favorite.'
    },
    {
      name: 'Kwame Asante',
      photo: 'https://i.pravatar.cc/150?img=13',
      rating: 5,
      quote: 'As a DJ, performing at Casa Fiesta is a dream. The sound system is pristine, the crowd is always engaged, and the production team is professional. This venue sets the standard.'
    },
    {
      name: 'Anika Bergström',
      photo: 'https://i.pravatar.cc/150?img=9',
      rating: 5,
      quote: 'The attention to detail is remarkable. From the lighting design to the cocktail menu, everything is curated to perfection. Casa Fiesta isn\'t just a night out - it\'s an experience.'
    },
    {
      name: 'Diego Morales',
      photo: 'https://i.pravatar.cc/150?img=14',
      rating: 5,
      quote: 'I travel for work constantly, and I always make time for Casa Fiesta when I\'m in Miami. The consistency in quality and the innovative events keep me coming back every time.'
    }
  ];

  const viralMoments = [
    {
      image: 'https://images.unsplash.com/photo-1571433172993-6738d818cfd9',
      caption: 'When the bass drops at 2am and everyone loses it',
      likes: '12.4k',
      comments: '847',
      shares: '2.1k'
    },
    {
      image: 'https://images.unsplash.com/photo-1680445530925-af01b317e0a6',
      caption: 'VIP lounge vibes hitting different tonight',
      likes: '8.7k',
      comments: '523',
      shares: '1.3k'
    },
    {
      image: 'https://images.unsplash.com/photo-1557156105-c792d5220944',
      caption: 'The neon tunnel entrance never gets old',
      likes: '15.2k',
      comments: '1.2k',
      shares: '3.4k'
    },
    {
      image: 'https://images.unsplash.com/photo-1571433172993-6738d818cfd9',
      caption: 'Best night of my life, no contest',
      likes: '9.8k',
      comments: '634',
      shares: '1.8k'
    },
    {
      image: 'https://images.unsplash.com/photo-1680445530925-af01b317e0a6',
      caption: 'The DJ lineup this weekend was insane',
      likes: '11.3k',
      comments: '789',
      shares: '2.2k'
    },
    {
      image: 'https://images.unsplash.com/photo-1557156105-c792d5220944',
      caption: 'Casa Fiesta really said luxury and delivered',
      likes: '13.6k',
      comments: '923',
      shares: '2.7k'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Community - Casa Fiesta</title>
        <meta name="description" content="Join the Casa Fiesta community. See what our members are saying and share your moments with #CasaFiesta." />
      </Helmet>

      <div className="min-h-screen bg-background text-white">
        <Header />

        <main className="pt-32 pb-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Header */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight text-white" style={{ letterSpacing: '-0.02em' }}>
                Join the community
              </h1>
              <p className="text-xl text-white/70 max-w-3xl mx-auto leading-relaxed">
                See what our members are saying and share your Casa Fiesta moments with #CasaFiesta
              </p>
            </motion.div>

            {/* Testimonials */}
            <section className="mb-24">
              <h2 className="text-3xl font-bold mb-8 text-white">What our members say</h2>
              <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
                {testimonials.map((testimonial, index) => (
                  <div key={index} className="break-inside-avoid">
                    <TestimonialCard testimonial={testimonial} index={index} />
                  </div>
                ))}
              </div>
            </section>

            {/* Viral Moments */}
            <section>
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-3xl font-bold text-white">Viral moments</h2>
                <span className="text-lg text-[hsl(var(--primary-text))] neon-text">#CasaFiesta</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {viralMoments.map((moment, index) => (
                  <ViralMomentCard key={index} moment={moment} index={index} />
                ))}
              </div>
            </section>

            {/* CTA */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="mt-24 text-center p-12 rounded-2xl bg-gradient-to-r from-primary/10 via-accent/10 to-secondary/10 border border-primary/20"
            >
              <h3 className="text-2xl md:text-3xl font-bold mb-4 text-white">Share your moments</h3>
              <p className="text-white/70 mb-6 max-w-2xl mx-auto">
                Tag us on social media with #CasaFiesta and your photos might be featured here
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <a
                  href="https://instagram.com/casafiesta"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[hsl(var(--primary-text))] hover:text-white transition-colors duration-200"
                >
                  @CasaFiesta on Instagram
                </a>
                <span className="text-white/40">•</span>
                <a
                  href="https://twitter.com/casafiesta"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[hsl(var(--primary-text))] hover:text-white transition-colors duration-200"
                >
                  @CasaFiesta on Twitter
                </a>
              </div>
            </motion.div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default CommunityPage;
