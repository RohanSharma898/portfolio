
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { LogOut, Plus, Edit, Trash2, DollarSign, Ticket, TrendingUp, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

const AdminDashboard = () => {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const [events, setEvents] = useState([]);
  const [orders, setOrders] = useState([]);
  const [isEventDialogOpen, setIsEventDialogOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState(null);
  const [eventForm, setEventForm] = useState({
    title: '',
    date: '',
    location: '',
    capacity: '',
    vibe: '',
    image: ''
  });

  useEffect(() => {
    const storedEvents = JSON.parse(localStorage.getItem('casaFiestaEvents') || '[]');
    const storedOrders = JSON.parse(localStorage.getItem('casaFiestaOrders') || '[]');
    setEvents(storedEvents);
    setOrders(storedOrders);
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/');
    toast.success('Logged out successfully');
  };

  const handleEventSubmit = (e) => {
    e.preventDefault();
    
    const newEvent = {
      id: editingEvent?.id || Date.now(),
      ...eventForm,
      capacity: parseInt(eventForm.capacity)
    };

    let updatedEvents;
    if (editingEvent) {
      updatedEvents = events.map(e => e.id === editingEvent.id ? newEvent : e);
      toast.success('Event updated');
    } else {
      updatedEvents = [...events, newEvent];
      toast.success('Event created');
    }

    setEvents(updatedEvents);
    localStorage.setItem('casaFiestaEvents', JSON.stringify(updatedEvents));
    setIsEventDialogOpen(false);
    setEditingEvent(null);
    setEventForm({ title: '', date: '', location: '', capacity: '', vibe: '', image: '' });
  };

  const handleDeleteEvent = (id) => {
    const updatedEvents = events.filter(e => e.id !== id);
    setEvents(updatedEvents);
    localStorage.setItem('casaFiestaEvents', JSON.stringify(updatedEvents));
    toast.success('Event deleted');
  };

  const handleEditEvent = (event) => {
    setEditingEvent(event);
    setEventForm({
      title: event.title,
      date: event.date,
      location: event.location,
      capacity: event.capacity.toString(),
      vibe: event.vibe,
      image: event.image
    });
    setIsEventDialogOpen(true);
  };

  const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);
  const totalTicketsSold = orders.reduce((sum, order) => 
    sum + order.items.reduce((itemSum, item) => itemSum + item.quantity, 0), 0
  );

  const ticketInventory = [
    { tier: 'VIP Experience', stock: 47, sold: 23, total: 70 },
    { tier: 'Premium', stock: 134, sold: 89, total: 223 },
    { tier: 'General Access', stock: 287, sold: 156, total: 443 }
  ];

  return (
    <>
      <Helmet>
        <title>Admin Dashboard - Casa Fiesta</title>
        <meta name="description" content="Casa Fiesta admin dashboard for event management and analytics." />
      </Helmet>

      <div className="min-h-screen bg-background text-white">
        {/* Header */}
        <header className="border-b border-primary/20 bg-background/95 backdrop-blur-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold bg-gradient-to-r from-[hsl(var(--primary-text))] via-[hsl(var(--accent-text))] to-[hsl(var(--secondary-text))] bg-clip-text text-transparent">
                Casa Fiesta Admin
              </div>
              <Button
                onClick={handleLogout}
                variant="outline"
                className="border-primary/20 text-white hover:text-white"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {/* Sales Statistics */}
          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-6 text-white">Sales overview</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="border-primary/20 bg-card">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-white/70 mb-1">Total revenue</p>
                      <p className="text-2xl font-bold text-[hsl(var(--primary-text))] neon-text">${totalRevenue.toFixed(2)}</p>
                    </div>
                    <DollarSign className="h-8 w-8 text-primary/50" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-primary/20 bg-card">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-white/70 mb-1">Tickets sold</p>
                      <p className="text-2xl font-bold text-[hsl(var(--primary-text))] neon-text">{totalTicketsSold}</p>
                    </div>
                    <Ticket className="h-8 w-8 text-primary/50" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-primary/20 bg-card">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-white/70 mb-1">Conversion rate</p>
                      <p className="text-2xl font-bold text-[hsl(var(--primary-text))] neon-text">67.8%</p>
                    </div>
                    <TrendingUp className="h-8 w-8 text-primary/50" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-primary/20 bg-card">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-white/70 mb-1">Total orders</p>
                      <p className="text-2xl font-bold text-[hsl(var(--primary-text))] neon-text">{orders.length}</p>
                    </div>
                    <Users className="h-8 w-8 text-primary/50" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </section>

          {/* Event Management */}
          <section className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-white">Event management</h2>
              <Dialog open={isEventDialogOpen} onOpenChange={setIsEventDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary text-white hover:bg-primary/90 neon-glow">
                    <Plus className="h-4 w-4 mr-2 text-white" />
                    Create event
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-background border-primary/20 text-white">
                  <DialogHeader>
                    <DialogTitle className="text-white">{editingEvent ? 'Edit event' : 'Create new event'}</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleEventSubmit} className="space-y-4">
                    <div>
                      <Label htmlFor="title" className="text-white">Event title</Label>
                      <Input
                        id="title"
                        value={eventForm.title}
                        onChange={(e) => setEventForm(prev => ({ ...prev, title: e.target.value }))}
                        required
                        className="mt-2 bg-background text-white border-primary/20 focus:border-primary placeholder:text-white/50"
                      />
                    </div>
                    <div>
                      <Label htmlFor="date" className="text-white">Date</Label>
                      <Input
                        id="date"
                        value={eventForm.date}
                        onChange={(e) => setEventForm(prev => ({ ...prev, date: e.target.value }))}
                        required
                        className="mt-2 bg-background text-white border-primary/20 focus:border-primary placeholder:text-white/50"
                      />
                    </div>
                    <div>
                      <Label htmlFor="location" className="text-white">Location</Label>
                      <Input
                        id="location"
                        value={eventForm.location}
                        onChange={(e) => setEventForm(prev => ({ ...prev, location: e.target.value }))}
                        required
                        className="mt-2 bg-background text-white border-primary/20 focus:border-primary placeholder:text-white/50"
                      />
                    </div>
                    <div>
                      <Label htmlFor="capacity" className="text-white">Capacity</Label>
                      <Input
                        id="capacity"
                        type="number"
                        value={eventForm.capacity}
                        onChange={(e) => setEventForm(prev => ({ ...prev, capacity: e.target.value }))}
                        required
                        className="mt-2 bg-background text-white border-primary/20 focus:border-primary placeholder:text-white/50"
                      />
                    </div>
                    <div>
                      <Label htmlFor="vibe" className="text-white">Vibe</Label>
                      <Input
                        id="vibe"
                        value={eventForm.vibe}
                        onChange={(e) => setEventForm(prev => ({ ...prev, vibe: e.target.value }))}
                        required
                        className="mt-2 bg-background text-white border-primary/20 focus:border-primary placeholder:text-white/50"
                      />
                    </div>
                    <div>
                      <Label htmlFor="image" className="text-white">Image URL</Label>
                      <Input
                        id="image"
                        value={eventForm.image}
                        onChange={(e) => setEventForm(prev => ({ ...prev, image: e.target.value }))}
                        required
                        className="mt-2 bg-background text-white border-primary/20 focus:border-primary placeholder:text-white/50"
                      />
                    </div>
                    <Button type="submit" className="w-full bg-primary text-white hover:bg-primary/90">
                      {editingEvent ? 'Update event' : 'Create event'}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            <Card className="border-primary/20 bg-card">
              <CardContent className="p-6">
                <Table>
                  <TableHeader>
                    <TableRow className="border-primary/20">
                      <TableHead className="text-white/70">Event</TableHead>
                      <TableHead className="text-white/70">Date</TableHead>
                      <TableHead className="text-white/70">Location</TableHead>
                      <TableHead className="text-white/70">Capacity</TableHead>
                      <TableHead className="text-white/70">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {events.length === 0 ? (
                      <TableRow className="border-primary/20 hover:bg-primary/5">
                        <TableCell colSpan={5} className="text-center text-white/60">
                          No events yet. Create your first event.
                        </TableCell>
                      </TableRow>
                    ) : (
                      events.map((event) => (
                        <TableRow key={event.id} className="border-primary/20 hover:bg-primary/5">
                          <TableCell className="font-medium text-white">{event.title}</TableCell>
                          <TableCell className="text-white">{event.date}</TableCell>
                          <TableCell className="text-white">{event.location}</TableCell>
                          <TableCell className="text-white">{event.capacity}</TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleEditEvent(event)}
                                className="text-white hover:text-white hover:bg-primary/20"
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleDeleteEvent(event.id)}
                                className="text-white hover:text-white hover:bg-destructive/20"
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </section>

          {/* Ticket Inventory */}
          <section>
            <h2 className="text-2xl font-bold mb-6 text-white">Ticket inventory</h2>
            <Card className="border-primary/20 bg-card">
              <CardContent className="p-6">
                <Table>
                  <TableHeader>
                    <TableRow className="border-primary/20">
                      <TableHead className="text-white/70">Tier</TableHead>
                      <TableHead className="text-white/70">Available</TableHead>
                      <TableHead className="text-white/70">Sold</TableHead>
                      <TableHead className="text-white/70">Total</TableHead>
                      <TableHead className="text-white/70">Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {ticketInventory.map((tier, index) => (
                      <TableRow key={index} className="border-primary/20 hover:bg-primary/5">
                        <TableCell className="font-medium text-white">{tier.tier}</TableCell>
                        <TableCell className="text-white">{tier.stock}</TableCell>
                        <TableCell className="text-white">{tier.sold}</TableCell>
                        <TableCell className="text-white">{tier.total}</TableCell>
                        <TableCell>
                          <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${
                            tier.stock > 100 ? 'bg-green-500/20 text-green-400' :
                            tier.stock > 50 ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-red-500/20 text-red-400'
                          }`}>
                            {tier.stock > 100 ? 'In stock' : tier.stock > 50 ? 'Low stock' : 'Very low'}
                          </span>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </section>
        </main>
      </div>
    </>
  );
};

export default AdminDashboard;
