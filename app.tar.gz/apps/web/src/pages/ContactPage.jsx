
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { MapPin, Phone, Mail, Send } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.message) {
      toast.error('Please fill in all required fields');
      return;
    }

    toast.success('Message sent! We\'ll get back to you soon.');
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: 'Location',
      content: '123 Neon Boulevard, Miami, FL 33139'
    },
    {
      icon: Phone,
      title: 'Phone',
      content: '+1 (305) 555-FIESTA'
    },
    {
      icon: Mail,
      title: 'Email',
      content: 'info@casafiesta.com'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Contact - Casa Fiesta</title>
        <meta name="description" content="Get in touch with Casa Fiesta. Contact us for event inquiries, partnerships, or general questions." />
      </Helmet>

      <div className="min-h-screen bg-background text-white">
        <Header />

        <main className="pt-32 pb-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="text-center mb-16">
                <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight text-white" style={{ letterSpacing: '-0.02em' }}>
                  Get in touch
                </h1>
                <p className="text-xl text-white/70 max-w-3xl mx-auto leading-relaxed">
                  Have questions? Want to partner with us? We'd love to hear from you.
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-12">
                {/* Contact Form */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                >
                  <Card className="border-primary/20 bg-card">
                    <CardContent className="p-8">
                      <form onSubmit={handleSubmit} className="space-y-6">
                        <div>
                          <Label htmlFor="name" className="text-white">Name *</Label>
                          <Input
                            id="name"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            required
                            className="mt-2 bg-background text-white placeholder:text-white/50 border-primary/20 focus:border-primary"
                            placeholder="Your name"
                          />
                        </div>

                        <div>
                          <Label htmlFor="email" className="text-white">Email *</Label>
                          <Input
                            id="email"
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={handleChange}
                            required
                            className="mt-2 bg-background text-white placeholder:text-white/50 border-primary/20 focus:border-primary"
                            placeholder="your.email@example.com"
                          />
                        </div>

                        <div>
                          <Label htmlFor="subject" className="text-white">Subject</Label>
                          <Input
                            id="subject"
                            name="subject"
                            value={formData.subject}
                            onChange={handleChange}
                            className="mt-2 bg-background text-white placeholder:text-white/50 border-primary/20 focus:border-primary"
                            placeholder="What is this about?"
                          />
                        </div>

                        <div>
                          <Label htmlFor="message" className="text-white">Message *</Label>
                          <Textarea
                            id="message"
                            name="message"
                            value={formData.message}
                            onChange={handleChange}
                            required
                            rows={6}
                            className="mt-2 bg-background text-white placeholder:text-white/50 border-primary/20 focus:border-primary resize-none"
                            placeholder="Tell us more..."
                          />
                        </div>

                        <Button
                          type="submit"
                          className="w-full bg-primary text-white hover:bg-primary/90 neon-glow transition-all duration-200 active:scale-[0.98]"
                        >
                          Send message
                          <Send className="ml-2 h-4 w-4" />
                        </Button>
                      </form>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Contact Info */}
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: 0.3 }}
                  className="space-y-8"
                >
                  {contactInfo.map((info, index) => (
                    <Card key={index} className="border-primary/20 hover:border-primary/40 transition-all duration-300 bg-card">
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <div className="p-3 rounded-lg bg-primary/10">
                            <info.icon className="h-6 w-6 text-primary" />
                          </div>
                          <div>
                            <h3 className="font-semibold mb-1 text-white">{info.title}</h3>
                            <p className="text-white/70">{info.content}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}

                  {/* Partnership Inquiry */}
                  <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-accent/5">
                    <CardContent className="p-6">
                      <h3 className="text-xl font-semibold mb-3 text-white">Partnership opportunities</h3>
                      <p className="text-white/70 mb-4 leading-relaxed">
                        Interested in collaborating with Casa Fiesta? We're always looking for innovative partnerships.
                      </p>
                      <a
                        href="mailto:partnerships@casafiesta.com"
                        className="text-[hsl(var(--primary-text))] hover:text-white transition-colors duration-200 font-medium"
                      >
                        partnerships@casafiesta.com
                      </a>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default ContactPage;
