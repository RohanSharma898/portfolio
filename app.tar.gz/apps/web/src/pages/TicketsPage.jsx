import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import TicketTierCard from '@/components/TicketTierCard';

const TicketsPage = () => {
  const ticketTiers = [
    {
      id: 'general',
      name: 'Male',
      price: 2499,
      availability: 'Limited spots available',
      benefits: [
        'Entry to main floor',
        'Access to bar area',
        'Standard drink prices',
        'Coat check included',
        'Photo booth access'
      ]
    },
    {
      id: 'premium',
      name: 'Female',
      price: 1499,
      availability: 'Limited spots available',
      benefits: [
        'Everything in General',
        'Priority entry line',
        'Access to premium lounge',
        'Two complimentary drinks',
        'Reserved seating area',
        'Meet & greet with DJs',
        'Exclusive merch discount'
      ]
    },
    {
      id: 'vip',
      name: 'Couples',
      price: 1999,
      availability: 'Very limited',
      benefits: [
        'Everything in Premium',
        'Private VIP entrance',
        'Dedicated VIP lounge access',
        'Bottle service included',
        'Personal concierge',
        'Backstage access',
        'Premium gift bag',
        'Valet parking included',
        'Priority event notifications'
      ]
    }
  ];

  return (
    <>
      <Helmet>
        <title>Tickets - Casa Fiesta</title>
        <meta name="description" content="Get your tickets to Casa Fiesta. Choose from General Access, Premium, or VIP Experience tiers." />
      </Helmet>

      <div className="min-h-screen bg-background text-white">
        <Header />

        <main className="pt-32 pb-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="text-center mb-16">
                <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight text-white" style={{ letterSpacing: '-0.02em' }}>
                  Choose your experience
                </h1>
                <p className="text-xl text-white/70 max-w-3xl mx-auto leading-relaxed">
                  Select the perfect tier for your night. All tickets include access to unforgettable moments.
                </p>
              </div>

              {/* Ticket Tiers - 2+1 Layout */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <TicketTierCard tier={ticketTiers[0]} index={0} />
                <TicketTierCard tier={ticketTiers[2]} index={1} isHighlighted={false} />
              </div>
              <div className="grid grid-cols-1 gap-8">
                <TicketTierCard tier={ticketTiers[1]} index={2} isHighlighted={true} />
              </div>

              {/* Additional Info */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="mt-16 p-8 rounded-2xl bg-muted/30 border border-primary/20"
              >
                <h3 className="text-xl font-semibold mb-4 text-white">Important information</h3>
                <ul className="space-y-2 text-white/70">
                  <li>• All tickets are non-refundable</li>
                  <li>• Must be 21+ with valid ID</li>
                  <li>• Dress code: Upscale casual to formal</li>
                  <li>• Tickets are transferable via email</li>
                  <li>• VIP upgrades available at the door (subject to availability)</li>
                </ul>
              </motion.div>
            </motion.div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default TicketsPage;