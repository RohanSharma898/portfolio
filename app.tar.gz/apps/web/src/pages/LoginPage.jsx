
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!email || !password) {
      toast.error('Please fill in all fields');
      return;
    }

    const success = login(email, password);
    if (success) {
      toast.success('Login successful');
      navigate('/admin');
    } else {
      toast.error('Invalid credentials. Try admin@casafiesta.com / admin123');
    }
  };

  return (
    <>
      <Helmet>
        <title>Admin Login - Casa Fiesta</title>
        <meta name="description" content="Admin login for Casa Fiesta staff." />
      </Helmet>

      <div className="min-h-screen bg-background flex items-center justify-center px-4 text-white">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="w-full max-w-md"
        >
          <div className="text-center mb-8">
            <div className="text-3xl font-bold bg-gradient-to-r from-[hsl(var(--primary-text))] via-[hsl(var(--accent-text))] to-[hsl(var(--secondary-text))] bg-clip-text text-transparent mb-2">
              Casa Fiesta
            </div>
            <p className="text-white/70">Admin portal</p>
          </div>

          <Card className="border-primary/20 bg-card">
            <CardHeader>
              <CardTitle className="flex items-center justify-center space-x-2 text-white">
                <LogIn className="h-5 w-5 text-primary" />
                <span>Staff login</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <Label htmlFor="email" className="text-white">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="mt-2 bg-background text-white placeholder:text-white/50 border-primary/20 focus:border-primary"
                    placeholder="admin@casafiesta.com"
                  />
                </div>

                <div>
                  <Label htmlFor="password" className="text-white">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="mt-2 bg-background text-white placeholder:text-white/50 border-primary/20 focus:border-primary"
                    placeholder="Enter your password"
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full bg-primary text-white hover:bg-primary/90 neon-glow transition-all duration-200 active:scale-[0.98]"
                >
                  Sign in
                </Button>

                <p className="text-sm text-center text-white/60">
                  Demo credentials: admin@casafiesta.com / admin123
                </p>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </>
  );
};

export default LoginPage;
