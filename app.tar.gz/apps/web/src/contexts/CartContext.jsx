import React, { createContext, useContext, useState, useEffect } from 'react';

const CartContext = createContext();

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within CartProvider');
  }
  return context;
};

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  useEffect(() => {
    const storedCart = localStorage.getItem('casaFiestaCart');
    if (storedCart) {
      setCartItems(JSON.parse(storedCart));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('casaFiestaCart', JSON.stringify(cartItems));
  }, [cartItems]);

  const addToCart = (ticket) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.id === ticket.id);
      if (existing) {
        return prev.map(item =>
          item.id === ticket.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...ticket, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (ticketId) => {
    setCartItems(prev => prev.filter(item => item.id !== ticketId));
  };

  const updateQuantity = (ticketId, quantity) => {
    if (quantity <= 0) {
      removeFromCart(ticketId);
      return;
    }
    setCartItems(prev =>
      prev.map(item =>
        item.id === ticketId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCartItems([]);
  };

  const getCartTotal = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const getCartCount = () => {
    return cartItems.reduce((count, item) => count + item.quantity, 0);
  };

  return (
    <CartContext.Provider value={{
      cartItems,
      isCartOpen,
      setIsCartOpen,
      addToCart,
      removeFromCart,
      updateQuantity,
      clearCart,
      getCartTotal,
      getCartCount
    }}>
      {children}
    </CartContext.Provider>
  );
};