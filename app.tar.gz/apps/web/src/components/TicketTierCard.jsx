import React from 'react';
import { motion } from 'framer-motion';
import { Check, Sparkles } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';

const TicketTierCard = ({ tier, index = 0, isHighlighted = false }) => {
  const { addToCart } = useCart();

  const handleAddToCart = () => {
    addToCart({
      id: tier.id,
      name: tier.name,
      price: tier.price,
      type: 'ticket'
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.15 }}
      className={isHighlighted ? 'scale-105' : ''}
    >
      <Card className={`relative overflow-hidden h-full flex flex-col ${
        isHighlighted
          ? 'border-primary/60 shadow-neon bg-primary/5'
          : 'border-primary/20 bg-card'
      } transition-all duration-300 hover:border-primary/60 hover:shadow-neon`}>
        {isHighlighted && (
          <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-primary via-accent to-secondary py-2 text-center">
            <span className="text-xs font-bold text-white flex items-center justify-center">
              <Sparkles className="h-3 w-3 mr-1 text-white" />
              Recommended
            </span>
          </div>
        )}
        <CardHeader className={isHighlighted ? 'pt-12' : 'pt-6'}>
          <CardTitle className="text-2xl font-bold text-center text-white">{tier.name}</CardTitle>
          <div className="text-center mt-4">
            <span className="text-4xl font-bold text-[hsl(var(--primary-text))] neon-text">₹{tier.price}</span>
            <span className="text-white/60 text-sm ml-2">per ticket</span>
          </div>
          {tier.availability && (
            <p className="text-center text-sm text-white/70 mt-2">{tier.availability}</p>
          )}
        </CardHeader>
        <CardContent className="flex-1 flex flex-col">
          <ul className="space-y-3 mb-6 flex-1">
            {tier.benefits.map((benefit, idx) => (
              <li key={idx} className="flex items-start space-x-2">
                <Check className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                <span className="text-sm text-white/80">{benefit}</span>
              </li>
            ))}
          </ul>
          <Button
            onClick={handleAddToCart}
            className={`w-full ${
              isHighlighted
                ? 'bg-primary text-white hover:bg-primary/90 neon-glow'
                : 'bg-secondary text-white hover:bg-secondary/90'
            } transition-all duration-200 active:scale-[0.98]`}
          >
            Add to cart
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default TicketTierCard;