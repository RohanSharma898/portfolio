import React from 'react';
import { X, Minus, Plus, ShoppingBag } from 'lucide-react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { useCart } from '@/contexts/CartContext';
import { toast } from 'sonner';

const ShoppingCart = () => {
  const {
    cartItems,
    isCartOpen,
    setIsCartOpen,
    removeFromCart,
    updateQuantity,
    clearCart,
    getCartTotal
  } = useCart();

  const handleCheckout = () => {
    if (cartItems.length === 0) {
      toast.error('Your cart is empty');
      return;
    }

    const order = {
      id: Date.now(),
      items: cartItems,
      total: getCartTotal(),
      date: new Date().toISOString()
    };

    const existingOrders = JSON.parse(localStorage.getItem('casaFiestaOrders') || '[]');
    localStorage.setItem('casaFiestaOrders', JSON.stringify([...existingOrders, order]));

    toast.success('Order confirmed! Check your email for tickets.');
    clearCart();
    setIsCartOpen(false);
  };

  return (
    <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
      <SheetContent className="w-full sm:max-w-lg bg-background border-primary/20 text-white">
        <SheetHeader>
          <SheetTitle className="flex items-center space-x-2 text-white">
            <ShoppingBag className="h-5 w-5 text-primary" />
            <span>Your cart</span>
          </SheetTitle>
        </SheetHeader>

        <div className="flex flex-col h-full mt-6">
          {cartItems.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center">
              <ShoppingBag className="h-16 w-16 text-white/50 mb-4" />
              <p className="text-lg font-medium text-white/80">Your cart is empty</p>
              <p className="text-sm text-white/60 mt-2">Add some tickets to get started</p>
            </div>
          ) : (
            <>
              <div className="flex-1 overflow-y-auto space-y-4 pr-2">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex items-center space-x-4 p-4 rounded-lg bg-muted/50 border border-primary/10">
                    <div className="flex-1">
                      <h4 className="font-semibold text-white">{item.name}</h4>
                      <p className="text-sm text-white/70">₹{item.price} per ticket</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-8 w-8 text-white border-primary/20 hover:bg-primary/20 hover:text-white"
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      >
                        <Minus className="h-4 w-4" />
                      </Button>
                      <span className="w-8 text-center font-medium text-white">{item.quantity}</span>
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-8 w-8 text-white border-primary/20 hover:bg-primary/20 hover:text-white"
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-white hover:text-white hover:bg-destructive/20"
                      onClick={() => removeFromCart(item.id)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>

              <div className="mt-6 space-y-4">
                <Separator className="bg-primary/20" />
                <div className="flex justify-between items-center text-lg font-bold text-white">
                  <span>Total</span>
                  <span className="text-[hsl(var(--primary-text))] neon-text">₹{getCartTotal().toFixed(2)}</span>
                </div>
                <Button
                  onClick={handleCheckout}
                  className="w-full bg-primary text-white hover:bg-primary/90 neon-glow transition-all duration-200 active:scale-[0.98]"
                >
                  Checkout
                </Button>
              </div>
            </>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default ShoppingCart;