
import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Twitter, Facebook, Mail, MapPin, Phone } from 'lucide-react';

const Footer = () => {
  const socialLinks = [
    { icon: Instagram, href: 'https://instagram.com/casafiesta', label: 'Instagram' },
    { icon: Twitter, href: 'https://twitter.com/casafiesta', label: 'Twitter' },
    { icon: Facebook, href: 'https://facebook.com/casafiesta', label: 'Facebook' }
  ];

  return (
    <footer className="bg-[#0A0E27] text-white border-t border-primary/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Brand */}
          <div>
            <div className="text-2xl font-bold bg-gradient-to-r from-[hsl(var(--primary-text))] via-[hsl(var(--accent-text))] to-[hsl(var(--secondary-text))] bg-clip-text text-transparent mb-4">
              Casa Fiesta
            </div>
            <p className="text-sm text-white/90 leading-relaxed">
              The most exclusive underground party experience. Where luxury meets energy.
            </p>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Contact</h3>
            <div className="space-y-3 text-sm text-white/90">
              <div className="flex items-center space-x-2">
                <MapPin className="h-4 w-4 text-[hsl(var(--primary-text))]" />
                <span>123 Neon Boulevard, Miami, FL 33139</span>
              </div>
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4 text-[hsl(var(--primary-text))]" />
                <span>+91 7778968464</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="h-4 w-4 text-[hsl(var(--primary-text))]" />
                <span>info@casafiesta.com</span>
              </div>
            </div>
          </div>

          {/* Social & Admin */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Connect</h3>
            <div className="flex space-x-4 mb-6">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-white/90 hover:text-[hsl(var(--primary-text))] transition-colors duration-200"
                  aria-label={social.label}
                >
                  <social.icon className="h-5 w-5" />
                </a>
              ))}
            </div>
            <p className="text-sm text-[hsl(var(--secondary-text))] mb-2 font-medium">#CasaFiesta</p>
            <Link
              to="/login"
              className="text-sm text-[hsl(var(--primary-text))] hover:text-white transition-colors duration-200"
            >
              Admin Login
            </Link>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-primary/20 flex flex-col sm:flex-row justify-between items-center text-sm text-white/80">
          <p>&copy; 2026 Casa Fiesta. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 sm:mt-0">
            <Link to="/privacy" className="hover:text-[hsl(var(--primary-text))] transition-colors duration-200">
              Privacy Policy
            </Link>
            <Link to="/terms" className="hover:text-[hsl(var(--primary-text))] transition-colors duration-200">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
