
import React from 'react';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';

const TestimonialCard = ({ testimonial, index = 0 }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Card className="bg-card border-primary/20 hover:border-primary/40 transition-all duration-300 h-full">
        <CardContent className="p-6">
          <div className="flex items-center space-x-4 mb-4">
            <Avatar className="h-12 w-12 rounded-xl">
              <AvatarImage src={testimonial.photo} alt={testimonial.name} />
              <AvatarFallback className="rounded-xl bg-primary/20 text-white">
                {testimonial.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-semibold text-white">{testimonial.name}</p>
              <div className="flex space-x-1">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-gold text-gold" />
                ))}
              </div>
            </div>
          </div>
          <blockquote className="text-white/80 leading-relaxed">
            "{testimonial.quote}"
          </blockquote>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default TestimonialCard;
