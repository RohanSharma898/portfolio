
import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, MapPin, Users, Sparkles } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const EventCard = ({ event, index = 0 }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Card className="group overflow-hidden bg-card border-primary/20 hover:border-primary/60 transition-all duration-300 hover:shadow-neon">
        <div className="relative h-64 overflow-hidden">
          <img
            src={event.image}
            alt={event.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
          <div className="absolute top-4 right-4">
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-accent/90 text-white neon-glow">
              <Sparkles className="h-3 w-3 mr-1 text-white" />
              {event.vibe}
            </span>
          </div>
        </div>
        <CardContent className="p-6">
          <h3 className="text-xl font-bold mb-3 text-white group-hover:text-[hsl(var(--primary-text))] transition-colors duration-200">
            {event.title}
          </h3>
          <div className="space-y-2 text-sm text-white/70">
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4 text-[hsl(var(--primary-text))]" />
              <span>{event.date}</span>
            </div>
            <div className="flex items-center space-x-2">
              <MapPin className="h-4 w-4 text-[hsl(var(--primary-text))]" />
              <span>{event.location}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Users className="h-4 w-4 text-[hsl(var(--primary-text))]" />
              <span>{event.capacity} attendees</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default EventCard;
